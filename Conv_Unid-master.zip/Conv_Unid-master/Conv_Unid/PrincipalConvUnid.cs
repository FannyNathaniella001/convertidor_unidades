﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conv_Unid
{
    class PrincipalConvUnid
    {   
        public void calcularPie() {


        }
        //calcularKm();
        //calcularMilla();
        //calcularYarda();
        //calcularPulg();
        //calcularCm();
        //calcularMm();
        //calcularMicra();
    }
}
